# last()

Returns a new HTMLdoc collection containing the last element in the collection.

## Returns

An HTMLdoc collection containing the element the last element in the collection, or an empty HTMLdoc collection if the collection is empty.
