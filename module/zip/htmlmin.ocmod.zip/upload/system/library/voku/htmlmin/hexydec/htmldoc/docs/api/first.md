# first()

Returns a new HTMLdoc collection containing the first element in the collection.

## Returns

An HTMLdoc collection containing the element the first element in the collection, or an empty HTMLdoc collection if the collection is empty.
